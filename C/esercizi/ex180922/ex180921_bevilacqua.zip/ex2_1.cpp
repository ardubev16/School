#include <iostream>

int main(int argc, char const *argv[]) {
  int a,b;
  printf("a=");
  scanf("%d",&a);
  printf("b=");
  scanf("%d",&b);
  printf("a+b=%d\n",a+b);

  return 0;
}
