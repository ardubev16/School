#include <iostream>

int main(int argc, char const *argv[]) {
  int a;
  printf("a=");
  scanf("%d",&a);
  printf("successivo=%d\n",a+1);
  printf("precedente=%d\n",a-1);

  return 0;
}
