#include <iostream>

int main(int argc, char const *argv[]) {
  float a,b,m;
  printf("a=");
  scanf("%f",&a);
  printf("b=");
  scanf("%f",&b);
  m=(a+b)/2;
  printf("media=%f\n",m);

  return 0;
}
