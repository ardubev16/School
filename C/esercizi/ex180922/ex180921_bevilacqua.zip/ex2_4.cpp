#include <iostream>

int main(int argc, char const *argv[]) {
  float a,b;
  printf("a=");
  scanf("%f",&a);
  printf("b=");
  scanf("%f",&b);
  printf("somma=%f\n",a+b);
  printf("sottrazione=%f\n",a-b);
  printf("moltiplicazione=%f\n",a*b);
  printf("divisione=%f\n",a/b);

  return 0;
}
